import { Component } from '@angular/core';

@Component({
  selector: 'app-comparador-de-precios',
  standalone: true,
  imports: [],
  templateUrl: './comparador-de-precios.component.html',
  styleUrl: './comparador-de-precios.component.css'
})
export class ComparadorDePreciosComponent {

}
