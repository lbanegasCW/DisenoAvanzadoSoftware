import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';

const environment = {
  production: false,
  apiUrl: 'http://localhost:8080',
  defaultLanguage: 'es',
  supportedLanguages: ['es', 'en'],
};

export interface Provincia {
  codProvincia: string;
  nomProvincia: string;
  codPais: string;
  nomPais: string;
}

export interface Localidad {
  nroLocalidad: number;
  nomLocalidad: string;
  codProvincia: string;
  nomProvincia: string;
  codPais: string;
  nomPais: string;
}

export interface Supermercado {
  nroSupermercado: number;
  razonSocial: string;
  urlServicio: string;
  tipoServicio: string;
  estadoServicio: boolean;
}

export interface Sucursal {
  nroSupermercado: number;
  nroSucursal: number;
  nomSucursal: string;
  calle: string;
  nroCalle: string;
  telefonos: string;
  coordLatitud: number;
  coordLongitud: number;
  horarioSucursal: string;
  serviciosDisponibles: string;
  habilitada: boolean;
  razonSocial: string;
  nroLocalidad: number;
  nomLocalidad: string;
  codProvincia: string;
  nomProvincia: string;
}

@Injectable({
  providedIn: 'root',
})
export class IndecService {
  private readonly API_URL = environment.apiUrl + '/api/v1';

  constructor(private http: HttpClient) {}

  getProvincias(): Observable<Provincia[]> {
    return this.http
      .get<Provincia[]>(`${this.API_URL}/provincias?codPais=ARG`)
      .pipe(catchError(this.handleError));
  }

  getLocalidades(codProvincia: string): Observable<Localidad[]> {
    return this.http
      .get<Localidad[]>(
        `${this.API_URL}/provincias/${codProvincia}/localidades?codPais=ARG`
      )
      .pipe(catchError(this.handleError));
  }

  getSupermercados(): Observable<Supermercado[]> {
    return this.http
      .get<Supermercado[]>(`${this.API_URL}/supermercados`)
      .pipe(catchError(this.handleError));
  }

  getSucursales(
    params: Record<string, string | number>
  ): Observable<Sucursal[]> {
    return this.http
      .get<Sucursal[]>(`${this.API_URL}/sucursales`, { params })
      .pipe(catchError(this.handleError));
  }

  getSucursalesCercanas(
    lat: number,
    lon: number,
    radio: number
  ): Observable<Sucursal[]> {
    return this.http
      .get<Sucursal[]>(`${this.API_URL}/sucursales/cerca`, {
        params: {
          lat: lat.toString(),
          lon: lon.toString(),
          radio: radio.toString(),
        },
      })
      .pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'Ha ocurrido un error en la aplicación';

    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error ${error.status}: ${
        error.error?.message || 'Error del servidor'
      }`;
    }

    return throwError(() => new Error(errorMessage));
  }
}
