import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./pages/inicio/inicio.component').then((m) => m.InicioComponent),
  },
  {
    path: 'supermercados',
    loadComponent: () =>
      import('./pages/supermercados/supermercados.component').then(
        (m) => m.SupermercadosComponent
      ),
  },
  {
    path: 'comparador-de-precios',
    loadComponent: () =>
      import(
        './pages/comparador-de-precios/comparador-de-precios.component'
      ).then((m) => m.ComparadorDePreciosComponent),
  },
];
