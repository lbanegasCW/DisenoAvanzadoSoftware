package ar.edu.ubp.das.super1.beans;

public class TipoServicioSucursalBean {
    private int nroTipoServicio;
    private String nomTipoServicio;

    public int getNroTipoServicio() {
        return nroTipoServicio;
    }

    public void setNroTipoServicio(int nroTipoServicio) {
        this.nroTipoServicio = nroTipoServicio;
    }

    public String getNomTipoServicio() {
        return nomTipoServicio;
    }

    public void setNomTipoServicio(String nomTipoServicio) {
        this.nomTipoServicio = nomTipoServicio;
    }
}
