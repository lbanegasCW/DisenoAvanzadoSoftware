package ar.edu.ubp.das.super1.services.jaxws;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

@XmlRootElement(name = "obtenerSucursales", namespace = "http://services.super1.das.ubp.edu.ar/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "obtenerSucursales", namespace = "http://services.super1.das.ubp.edu.ar/")
public class ObtenerSucursales {}
