package ar.edu.ubp.das.super1.repositories;
import ar.edu.ubp.das.super1.beans.*;
import ar.edu.ubp.das.super1.components.SimpleJdbcCallFactory;
import ar.edu.ubp.das.super1.dto.ProductoDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class SupermercadoRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public String getSucursalesXml() {
        return jdbcTemplate.query(
                "EXEC dbo.sp_get_sucursales",
                rs -> rs.next() ? rs.getString(1) : null
        );
    }

    public String getProductosXmlAll() {
        return jdbcTemplate.query(
                "EXEC dbo.sp_get_productos",
                rs -> rs.next() ? rs.getString(1) : null
        );
    }

}
